import Form1 from './Components/Form1'
import './App.css';

function App() {
  return (
    <div>
      <Form1/>
    </div>
  )
}

export default App;
